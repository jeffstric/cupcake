-- phpMyAdmin SQL Dump
-- version 3.4.8
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2012 年 01 月 13 日 18:08
-- 服务器版本: 5.1.54
-- PHP 版本: 5.3.5-1ubuntu7.4

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `cupcake`
--

-- --------------------------------------------------------

--
-- 表的结构 `adsence`
--

CREATE TABLE IF NOT EXISTS `adsence` (
  `A_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `AS_id` int(11) NOT NULL,
  `A_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `A_url` varchar(80) COLLATE utf8_unicode_ci NOT NULL DEFAULT '#',
  `A_img` varchar(30) COLLATE utf8_unicode_ci NOT NULL DEFAULT '0',
  `A_sort` int(10) unsigned NOT NULL,
  `A_active` tinyint(1) NOT NULL DEFAULT '0',
  `A_start` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `A_end` datetime NOT NULL DEFAULT '2300-00-00 00:00:00',
  `A_adder` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `A_addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`A_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=18 ;

--
-- 转存表中的数据 `adsence`
--

INSERT INTO `adsence` (`A_id`, `AS_id`, `A_name`, `A_url`, `A_img`, `A_sort`, `A_active`, `A_start`, `A_end`, `A_adder`, `A_addtime`) VALUES
(1, 1, '首页幻灯片广告一', '#', '1.jpg', 1, 1, '2012-01-12 16:00:00', '2012-01-28 00:00:00', 'jeff', 1325036675),
(2, 1, '首页幻灯片广告二', '#', '1.jpg', 2, 1, '2012-01-13 03:23:40', '2012-01-28 00:00:00', 'jeff', 1325049642),
(3, 1, '首页幻灯片广告三', '#', '1.jpg', 3, 1, '2012-01-16 16:00:00', '2012-01-25 00:00:00', 'jeff', 1325049701),
(4, 2, '全局广告一', '#', '2.gif', 4, 1, '2012-01-13 03:24:00', '2012-01-28 00:00:00', 'jeff', 1325051042),
(5, 2, '全局广告一', '#', '3.gif', 5, 1, '2012-01-13 03:24:06', '2012-01-28 00:00:00', 'jeff', 1325051077),
(6, 2, '全局广告一', '#', '4.gif', 6, 1, '2012-01-12 16:00:00', '2012-02-18 00:00:00', 'jeff', 1325051082),
(7, 3, '全局广告二', '#', '3.gif', 7, 1, '2012-01-13 03:24:31', '2012-01-28 00:00:00', 'jeff', 1325051077),
(8, 2, '全局广告二', '#', '3.gif', 8, 1, '2012-01-13 03:24:41', '2012-01-28 00:00:00', 'jeff', 1325051077),
(9, 3, '全局广告二', '#', '3.gif', 9, 1, '2012-01-13 03:24:53', '2012-01-28 00:00:00', 'jeff', 1325051077),
(10, 4, '全局广告三', '#', '3.gif', 10, 1, '2012-01-13 03:25:01', '2012-01-28 00:00:00', 'jeff 	', 1325051077),
(11, 4, '全局广告三', '#', '3.gif', 11, 1, '2012-01-13 03:25:13', '2012-01-28 00:00:00', 'jeff', 1325051077),
(12, 4, '全局广告三', '#', '3.gif', 12, 1, '2012-01-13 03:25:21', '2012-01-28 00:00:00', 'jeff', 1325051077),
(13, 1, '首页幻灯片广告四', '#', '1.jpg', 24, 1, '2012-01-12 16:00:00', '2012-01-28 00:00:00', 'jeff', 1325036675);

-- --------------------------------------------------------

--
-- 表的结构 `adsence_style`
--

CREATE TABLE IF NOT EXISTS `adsence_style` (
  `AS_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `AS_keyname` varchar(20) COLLATE utf8_unicode_ci NOT NULL,
  `AS_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `AS_des` varchar(240) COLLATE utf8_unicode_ci NOT NULL,
  `AS_default_num` int(11) NOT NULL DEFAULT '1',
  `AS_adder` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `AS_addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`AS_id`),
  UNIQUE KEY `AS_keyname` (`AS_keyname`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `adsence_style`
--

INSERT INTO `adsence_style` (`AS_id`, `AS_keyname`, `AS_name`, `AS_des`, `AS_default_num`, `AS_adder`, `AS_addtime`) VALUES
(1, 'flash', '首页幻灯片广告位', '传说中地广告位', 4, 'jeff', 1325039245),
(2, 'global_ad1', '全局广告位一', '全局广告位', 1, 'jeff', 1325050371),
(3, 'global_ad2', '全局广告位二', '全局广告位 ', 1, 'jeff 	', 1325050371),
(4, 'global_ad3', '全局广告位三', '全局广告', 1, 'jeff', 1325050378);

-- --------------------------------------------------------

--
-- 表的结构 `category`
--

CREATE TABLE IF NOT EXISTS `category` (
  `C_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `C_parent` int(11) NOT NULL DEFAULT '0',
  `C_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `C_des` varchar(150) COLLATE utf8_unicode_ci NOT NULL,
  `C_adder` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `C_addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`C_id`),
  UNIQUE KEY `C_name` (`C_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `category`
--

INSERT INTO `category` (`C_id`, `C_parent`, `C_name`, `C_des`, `C_adder`, `C_addtime`) VALUES
(8, 0, '蛋糕分类1', '蛋糕分类1', 'jeff', 1326443553),
(9, 0, '测试分类', '123', 'jeff', 1326445555),
(11, 8, 'dsfa', '', 'jeff', 1326448442);

-- --------------------------------------------------------

--
-- 表的结构 `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `L_U_id` int(10) unsigned NOT NULL,
  `L_S_id` varchar(40) COLLATE utf8_unicode_ci NOT NULL,
  `L_unique` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `L_time` int(10) unsigned NOT NULL,
  PRIMARY KEY (`L_U_id`),
  UNIQUE KEY `L_S_id_unique` (`L_S_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `login`
--

INSERT INTO `login` (`L_U_id`, `L_S_id`, `L_unique`, `L_time`) VALUES
(1, '656ddaa4b5fbdbd879c6db802eb0a292', '9774f0ff666d01cc1.45007245', 1326446182);

-- --------------------------------------------------------

--
-- 表的结构 `product`
--

CREATE TABLE IF NOT EXISTS `product` (
  `P_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `P_C_id` int(10) unsigned NOT NULL,
  `P_name` varchar(60) COLLATE utf8_unicode_ci NOT NULL,
  `P_des` text COLLATE utf8_unicode_ci NOT NULL,
  `P_img` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `P_tmb` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `P_sort` int(10) unsigned NOT NULL,
  `P_index` tinyint(1) NOT NULL DEFAULT '0',
  `P_adder` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `P_addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`P_id`),
  UNIQUE KEY `P_name` (`P_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci COMMENT='商品表' AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `product`
--

INSERT INTO `product` (`P_id`, `P_C_id`, `P_name`, `P_des`, `P_img`, `P_tmb`, `P_sort`, `P_index`, `P_adder`, `P_addtime`) VALUES
(1, 8, '商品名称', '<p>\r\n	&nbsp;</p>\r\n<h5 style="color: rgb(0, 0, 0); font-family: Simsun; ">\r\n	商品名称商品名称商品名称商品名称商品名称</h5>\r\n', '1326444092824.jpg', 'default.jpg', 1, 1, 'jeff', 1326444093);

-- --------------------------------------------------------

--
-- 表的结构 `site`
--

CREATE TABLE IF NOT EXISTS `site` (
  `S_key` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `S_value` text COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`S_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- 转存表中的数据 `site`
--

INSERT INTO `site` (`S_key`, `S_value`) VALUES
('about', '关于我们内容'),
('contact', '联系我们内容test');

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `U_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `U_name` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `U_pw` varchar(50) COLLATE utf8_unicode_ci NOT NULL,
  `U_right` tinyint(1) NOT NULL,
  `U_adder` varchar(30) COLLATE utf8_unicode_ci NOT NULL,
  `U_addtime` int(10) unsigned NOT NULL,
  PRIMARY KEY (`U_id`),
  UNIQUE KEY `name_unique` (`U_name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`U_id`, `U_name`, `U_pw`, `U_right`, `U_adder`, `U_addtime`) VALUES
(1, 'jeff', 'e10adc3949ba59abbe56e057f20f883e', 63, 'system', 1324971416);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
